Please extract the package to any folder before opening the installer. It will automatically install and run the launcher, you don't need to do anything.

DON'T REMOVE ANYTHING FROM THE INSTALLATION FOLDER.